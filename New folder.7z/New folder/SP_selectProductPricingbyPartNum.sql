USE [PriceMetrics]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SP_selectProductPricingbyPartNum]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SP_selectProductPricingbyPartNum]
GO

USE [PriceMetrics]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ==================================================================
-- Author:		Jinyu Chen
-- Email:       jinyuc@fireracker.com
-- Create date: 03/16/2017 12:50:13
-- ==================================================================

CREATE PROCEDURE [dbo].[SP_selectProductPricingbyPartNum]
	@part_num         VARCHAR(100)   = NULL,
	@part_num_list    VARCHAR(MAX)   = NULL,
	@begin_date       NVARCHAR(50)   = NULL,
	@end_date         NVARCHAR(50)   = NULL,
	@debug            TINYINT        = 0

AS
BEGIN
	SET NOCOUNT ON;

	IF @part_num IS NOT NULL AND @part_num_list IS NOT NULL
		BEGIN
			RAISERROR (N'ONLY ACCPETS ONE VALUE FROM @part_num AND @part_num_list AT SAME TIME', 16, 1);
			RETURN 1;
		END
	ELSE IF @part_num IS NULL AND @part_num_list IS NULL
		BEGIN
			RAISERROR (N'AT LEAST ONE OF VALUE FROM @part_num OR @part_num_list SHOULD BE PROVIDED.', 16, 1);
			RETURN 1;
		END
	ELSE
		BEGIN
			IF @begin_date IS NULL AND @end_date IS NULL
				BEGIN
					SET @end_date = CONVERT(date, getdate())
					SET @begin_date = CONVERT(date, DATEADD(day, DATEDIFF(day, 0, @end_date) - 7, 0))
				END
			ELSE IF @end_date IS NOT NULL AND @begin_date IS NULL
				BEGIN
					IF ISDATE(@end_date) = 1
						BEGIN
							SET @begin_date = CONVERT(date, DATEADD(day, DATEDIFF(day, 0, @end_date) - 7, 0))
						END
					ELSE
						BEGIN
							RAISERROR (N'@end_date IS NOT CORRECT DATE FORMAT, LIKE: 2017-03-09.', 16, 1);
							RETURN 1;
						END
				END
			ELSE IF @end_date IS NULL AND @begin_date IS NOT NULL
				BEGIN
					IF ISDATE(@begin_date) = 1
						BEGIN
							SET @end_date = CONVERT(date, DATEADD(day, DATEDIFF(day, 0, @begin_date) + 7, 0))
						END
					ELSE
						BEGIN
							RAISERROR (N'@begin_date IS NOT CORRECT DATE FORMAT, LIKE: 2017-03-09.', 16, 1);
							RETURN 1;
						END
				END
			ELSE
				BEGIN
					IF ISDATE(@begin_date) = 1 AND ISDATE(@end_date) = 1
						BEGIN
							IF @begin_date > @end_date 
								BEGIN
									RAISERROR (N'@begin_date CANNOT OLDER THAN @end_date.', 16, 1);
									RETURN 1;
								END
						END
					ELSE
						BEGIN
							RAISERROR (N'@begin_date OR @end_date IS NOT CORRECT DATE FORMAT, LIKE: 2017-03-09.', 16, 1);
							RETURN 1;
						END
				END
			IF @part_num IS NOT NULL
				BEGIN
					SELECT 
						p.part_number AS PartNumber, 
						p.name AS ProductName, 
						m.name AS Manufacturer,
						s.name AS SellerName,
						s.trusted_store AS IsTrustedStore,
						s.seller_rating AS SellerRating,
						s.reviews AS Reviews,
						pm.date AS [Date],
						pm.base_price AS BasePrice,
						pm.tax AS Tax,
						pm.shipping_fee AS ShippingFee,
						pm.total_price AS TotalPrice
					FROM price_metrics AS pm 
					JOIN seller_products AS sp ON sp.seller_product_id  = pm.seller_product_id
					JOIN products AS p ON p.product_id = sp.product_id
					JOIN sellers AS s ON s.seller_id = sp.seller_id
					JOIN manufacturers AS m ON m.manufacturer_id = p.manufacturer_id
					WHERE p.part_number = @part_num AND PM.date >= @begin_date AND PM.date <= @end_date
					ORDER BY pm.date, p.name
				END
			ELSE IF @part_num_list IS NOT NULL
				BEGIN
					SELECT 
						p.part_number AS PartNumber, 
						p.name AS ProductName, 
						m.name AS Manufacturer,
						s.name AS SellerName,
						s.trusted_store AS IsTrustedStore,
						s.seller_rating AS SellerRating,
						s.reviews AS Reviews,
						pm.date AS [Date],
						pm.base_price AS BasePrice,
						pm.tax AS Tax,
						pm.shipping_fee AS ShippingFee,
						pm.total_price AS TotalPrice
					FROM price_metrics AS pm 
					JOIN seller_products AS sp ON sp.seller_product_id  = pm.seller_product_id
					JOIN products AS p ON p.product_id = sp.product_id
					JOIN sellers AS s ON s.seller_id = sp.seller_id
					JOIN manufacturers AS m ON m.manufacturer_id = p.manufacturer_id
					JOIN dbo.iter_charlist_to_tbl(@part_num_list, DEFAULT) AS i ON i.str = p.part_number
					WHERE PM.date >= @begin_date AND PM.date <= @end_date
					ORDER BY pm.date, p.name
				END
		END
			
END