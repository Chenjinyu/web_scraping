import os, sys
import traceback
import shutil
import threading
from os.path import basename, exists, dirname, abspath, join as pathjoin

from sqlalchemy import desc
from sqlalchemy.orm import sessionmaker

from UserLibs import settings, ComFun
from UserLibs.Config import ParserConfigFile, Gmail, FileAndConsoleLogConfig
from UserLibs.Database import DBEngine

'''
it will be triggered by every hour on the server on which the SQL Server existed. no multi-threading.
@author: jinyuc@fireracker.com
@date: 02/13/2017
'''

def run_prod_price_xml_import():
    for subdir, dirs, files in os.walk(NEW_PROD_PRICE_XML_PATH):
        for prod_price_f in files:
            if exists(pathjoin(subdir, prod_price_f)) and prod_price_f.endswith('.xml'):
                ongoing_file_path = pathjoin(ONGOING_PROD_PRICE_XML_PATH, prod_price_f)
                try:
                    shutil.move(pathjoin(subdir, prod_price_f), ongoing_file_path)
                except Exception,e:
                    LOGGING.warn('File[%s] does not exists any more. raised at shutil.move exception.' % prod_price_f)
                
                if exists(ongoing_file_path):
                    try:
                        xml_writer = open(ongoing_file_path, 'rb')
                        xml_readlines = xml_writer.readlines()
                        prod_price_xml = ''
                        for line in xml_readlines:
                            prod_price_xml += line.strip()
                        
                        xml_writer.close()
                        
                        if prod_price_xml:
                            try:
                                LOGGING.info('execute uspProductPriceInsertXML @xml = %s ' % prod_price_f)
                                SESSION.execute("uspProductPriceInsertXML @xml='%s'" % prod_price_xml)
                                SESSION.commit()
                                shutil.move(ongoing_file_path, pathjoin(SUCC_PROD_PRICE_XML_PATH, prod_price_f))
                            except Exception, e:
                                LOGGING.error(e)
                                shutil.move(ongoing_file_path, pathjoin(FAILED_PROD_PRICE_XML_PATH, prod_price_f))
                               
                    except Exception, e:
                        LOGGING.error('error happen: %s' % traceback.format_exc())
                        return False
                        
                else:
                    LOGGING.error('Prod price xml file[%s] does not exist' % ongoing_file_path)
                    return False
    
    LOGGING.warn('There are no *.xml file anymore under the directory[%s]' % NEW_PROD_PRICE_XML_PATH)    


if __name__ == "__main__":
    
    try:
        '''
        move part_num.xml into ongoing folder and read and loading it into USP(user stored procedure.) 
        '''
        LOGGING = FileAndConsoleLogConfig(file_name = '.'.join(basename(__file__).split('.')[:-1]), level = 'INFO')
        READ_CONFIG = ParserConfigFile(r'./etc/price_metric_config.cfg')
        
        CUR_DATE = ComFun.getCurrentDate()
        price_xml_base_path         = READ_CONFIG.get_item_value('XML_FOLDER', 'price_xml_base_path')
        NEW_PROD_PRICE_XML_PATH     = pathjoin(price_xml_base_path, 'new')
        ONGOING_PROD_PRICE_XML_PATH = pathjoin(price_xml_base_path, 'ongoing')
        SUCC_PROD_PRICE_XML_PATH    = pathjoin(price_xml_base_path, 'succ', CUR_DATE)
        FAILED_PROD_PRICE_XML_PATH  = pathjoin(price_xml_base_path, 'failed', CUR_DATE)
        
        if not exists(ONGOING_PROD_PRICE_XML_PATH): os.makedirs(ONGOING_PROD_PRICE_XML_PATH)
        if not exists(SUCC_PROD_PRICE_XML_PATH):    os.makedirs(SUCC_PROD_PRICE_XML_PATH)
        if not exists(FAILED_PROD_PRICE_XML_PATH):  os.makedirs(FAILED_PROD_PRICE_XML_PATH)
        
        
        read_config      = ParserConfigFile(DBEngine.get_common_db_config_full_path())
        db_config_list   = read_config.get_items_list('PRICE_METRICS')
        DBEngine_handler = DBEngine(*db_config_list)
        DBSession        = sessionmaker(autocommit=False, autoflush=False, bind=DBEngine_handler.get_engine())
        
        SESSION = DBSession()
        run_prod_price_xml_import()
        LOGGING.info('import_prod_price_xml.py are done!')
            
        SESSION.close()
        
    except Exception, e:
        if LOGGING:
            LOGGING.error('Something wrong in the main: %s.' % traceback.format_exc())
        else:
            print traceback.format_exc()
            
            