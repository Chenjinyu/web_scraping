import os, sys
import traceback
import shutil
import threading
from os.path import basename, exists, dirname, abspath, join as pathjoin

from sqlalchemy import desc
from sqlalchemy.orm import sessionmaker

from UserLibs import settings, ComFun
from UserLibs.Config import ParserConfigFile, Gmail, FileAndConsoleLogConfig
from UserLibs.Database import DBEngine


'''
it will be triggered by every hour on the server on which the SQL Server existed. no multi-threading.
@author: jinyuc@fireracker.com
@date: 02/13/2017
'''

def run_unstable_pn_xml_import():
    for subdir, dirs, files in os.walk(NEW_UNSTABLE_PN_XML_PATH):
        for unstable_pn_f in files:
            if exists(pathjoin(subdir, unstable_pn_f)) and unstable_pn_f.endswith('.xml'):
                ongoing_file_path = pathjoin(ONGOING_UNSTABLE_PN_XML_PATH, unstable_pn_f)
                try:
                    shutil.move(pathjoin(subdir, unstable_pn_f), ongoing_file_path)
                except Exception,e:
                    LOGGING.warn('File[%s] does not exists. raised at shutil.move exception.' % unstable_pn_f)
                
                if exists(ongoing_file_path):
                    try:
                        xml_writer = open(ongoing_file_path, 'rb')
                        xml_readlines = xml_writer.readlines()
                        part_num_xml = ''
                        for line in xml_readlines:
                            part_num_xml += line.strip()
                        
                        xml_writer.close()
                        
                        if part_num_xml:
                            try:
                                LOGGING.info('execute uspUnstablePartNumXML @xml = %s ' % unstable_pn_f)
                                SESSION.execute("uspUnstablePartNumXML @xml='%s'" % part_num_xml)
                                SESSION.commit()
                                shutil.move(ongoing_file_path, pathjoin(SUCC_UNSTABLE_PN_XML_PATH, unstable_pn_f))
                            except Exception, e:
                                LOGGING.error(e)
                                shutil.move(ongoing_file_path, pathjoin(FAILED_UNSTABLE_PN_XML_PATH, unstable_pn_f))
                      
                    except Exception, e:
                        LOGGING.error('error happen: %s' % traceback.format_exc())
                        return False
                        
                else:
                    LOGGING.error('Prod price xml file[%s] does not exist' % ongoing_file_path)
                    return False
    
    LOGGING.warn('There are no *.xml file anymore under the directory[%s]' % NEW_UNSTABLE_PN_XML_PATH)    


if __name__ == "__main__":
    
    try:
        '''
        move part_num.xml into ongoing folder and read and loading it into USP(user stored procedure.) 
        '''
        LOGGING = FileAndConsoleLogConfig(file_name = '.'.join(basename(__file__).split('.')[:-1]), level = 'INFO')
        READ_CONFIG = ParserConfigFile(r'./etc/price_metric_config.cfg')
        
        # how many stores' price data of the related product will be pulled out.
        CUR_DATE = ComFun.getCurrentDate()
        unstable_pn_xml_base_path        = READ_CONFIG.get_item_value('XML_FOLDER', 'unstable_pn_xml_base_path')
        NEW_UNSTABLE_PN_XML_PATH     = pathjoin(unstable_pn_xml_base_path, 'new')
        ONGOING_UNSTABLE_PN_XML_PATH = pathjoin(unstable_pn_xml_base_path, 'ongoing')
        SUCC_UNSTABLE_PN_XML_PATH    = pathjoin(unstable_pn_xml_base_path, 'succ', CUR_DATE)
        FAILED_UNSTABLE_PN_XML_PATH  = pathjoin(unstable_pn_xml_base_path, 'failed', CUR_DATE)
        
        if not exists(ONGOING_UNSTABLE_PN_XML_PATH): os.makedirs(ONGOING_UNSTABLE_PN_XML_PATH)
        if not exists(SUCC_UNSTABLE_PN_XML_PATH):    os.makedirs(SUCC_UNSTABLE_PN_XML_PATH)
        if not exists(FAILED_UNSTABLE_PN_XML_PATH):  os.makedirs(FAILED_UNSTABLE_PN_XML_PATH)
        read_config      = ParserConfigFile(DBEngine.get_common_db_config_full_path())
        db_config_list   = read_config.get_items_list('PRICE_METRICS')
        DBEngine_handler = DBEngine(*db_config_list)
        DBSession        = sessionmaker(autocommit=False, autoflush=False, bind=DBEngine_handler.get_engine())
        
        SESSION = DBSession()
        
        run_unstable_pn_xml_import()
        LOGGING.info('import_unstable_part_num_chk_xml.py are done!')
            
        SESSION.close()
                
    except Exception, e:
        if LOGGING:
            LOGGING.error('Something wrong in the main: %s.' % traceback.format_exc())
        else:
            print traceback.format_exc()
            
            