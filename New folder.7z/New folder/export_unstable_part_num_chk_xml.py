import os, sys
from re import sub
from decimal import Decimal
import time
import datetime
import traceback
import shutil
import base64
import threading
from os.path import basename, exists, dirname, abspath, join as pathjoin
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

import webdrive_fun
from UserLibs import settings, ComFun
from UserLibs.Config import ParserConfigFile, FileAndConsoleLogConfig

__version__ = '0.0.2'

'''
version: 0.0.1
export_unstable_part_num_chk_xml.py used to search part num in google shopping engine, verfiy the part number on webpage, and get store link and manufacturer info.
xml format:
<?xml version="1.0" encoding="UTF-8" ?>
<product>
    <part_num>part number with b64encode</part_num>
    <is_match_store_list_link>True</is_match_store_list_link>
    <is_correct_part_num>False</is_correct_part_num>
    <prod_name>product name with b64encode</prod_name>
    <manufacturer_name>manufacturer name with b64encode</manufacturer_name>
    <product_store_link>Product store link with b64encode</product_store_link>
</product>

version 0.0.2
add the time, script will be stop after the day or night time. 
script will detect if present is day, it will run the threading instance with the days;
if preset is night, it will run the threading instance with the night.

@author: jinyuc@fireracker.com
@date: 02/08/2017
'''


def search_and_verify_part_num(part_num):
    try:
        driver = webdriver.Chrome(executable_path=r'driver/chromedriver.exe')  # Optional argument, if not specified will search path.
    except Exception, e:
        LOGGING.error('Part Number [%s], Error happens while webdriver initializing: %s' % (part_num, traceback.format_exc()))
        return
     
    try:
        # 1. search with google shopping engine.
        if part_num:
            shopping_search_link = GOOGLE_BASE_LINK + '/#q=' + part_num + '&tbm=shop'
        else:
            LOGGING.error('Part Num cannot be empty')
            return 
        
        driver.get(shopping_search_link)
        
        part_num_xml = '<?xml version="1.0" encoding="UTF-8" ?><product><part_num>%s</part_num>' % base64.b64encode(part_num)
        
        # get the best one matched store link
        match_store_list_link = webdrive_fun.get_best_match(driver)
        
        if match_store_list_link:
            # it will go to the google shopping product list, and we need to verify the part num and 
            # get the manufacturer name back clicking the link of 'View all details' at the bottom of page.
            driver.get(match_store_list_link)
            
            part_num_xml += '<is_match_store_list_link>True</is_match_store_list_link>'
            LOGGING.info('Get Match Store Link: [%s].' % match_store_list_link)
            time.sleep(3)
            
            is_correct_part_num, prod_name, manufacturer_name = webdrive_fun.verify_part_num(driver, part_num)
            if is_correct_part_num and manufacturer_name and prod_name:
                part_num_xml += '<is_correct_part_num>True</is_correct_part_num><prod_name>%s</prod_name><manufacturer_name>%s</manufacturer_name><product_store_link>%s</product_store_link>' \
                % (base64.b64encode(prod_name), base64.b64encode(manufacturer_name), base64.b64encode(match_store_list_link))
            else:
                part_num_xml += '<is_correct_part_num>False</is_correct_part_num><prod_name></prod_name><manufacturer_name></manufacturer_name><product_store_link></product_store_link>' 
        else:
           part_num_xml += '<is_match_store_list_link>False</is_match_store_list_link><is_correct_part_num>False</is_correct_part_num><prod_name></prod_name><manufacturer_name></manufacturer_name><product_store_link></product_store_link>'
                
        driver.quit()
        
        part_num_xml += '</product>'
        
        return export_part_num_xml(NEW_PN_XML_BASE_PATH, part_num, part_num_xml)
    
    except Exception, e:
        LOGGING.error('Part Number [%s], Error happens: %s' % (part_num, traceback.format_exc()))
        if driver:
            driver.quit()


def export_part_num_xml(write_xml_path, part_num, part_num_xml_str):
    if not exists(write_xml_path): os.makedirs(write_xml_path)
    
    try:
        xml_writer = open(pathjoin(write_xml_path, part_num + '_' +  CUR_DATE + '.xml'), 'wb')
        xml_writer.write(part_num_xml_str)
        
        if xml_writer:
            xml_writer.close()
        return True
    except Exception, e:
        LOGGING.error('Save XML file failed. %s' % e)
        return False


def pickup_a_part_num():
    for subdir, dirs, files in os.walk(NEW_UNSTABLE_PART_NUM_FOLDER):
        for pn_f in files:
            if pn_f.endswith('.txt'):
                try:
                    ongoing_path = pathjoin(ONGOING_UNSTABLE_PART_NUM_FOLDER, pn_f)
                    shutil.move(pathjoin(NEW_UNSTABLE_PART_NUM_FOLDER, pn_f), ongoing_path)
                    return ongoing_path
                except Exception, e:
                    LOGGING.error('Move file to going file %s error' % ongoing_path)
                    continue
                
    return False


def begin_read_unstable_part_num():
    
    if TIME_FLAG == 'day_time': break_time_str = NIGHT_TIME 
    elif TIME_FLAG == 'night_time': break_time_str = DAY_TIME
    else:
        break_time_str = False
    if not ComFun.is_day_night_time_switch(break_time_str):
        LOGGING.info('The time is close to the time node. break.')
        return
    
    ongoing_path = pickup_a_part_num()
    LOGGING.info('Pick up the file: %s' % ongoing_path)
    
    while(ongoing_path):
        if not ongoing_path:
            LOGGING.error('No part num file to read in new foler')
            continue 
        try:
            FILE_HANDLER = open(ongoing_path, 'r')
            part_num_list = FILE_HANDLER.readlines()
            for part_num in part_num_list:
                part_num = part_num.strip()
                LOGGING.info('--------------------- Part Num [ %s ] ---------------------->>>' % part_num)
                search_and_verify_part_num(part_num)
                LOGGING.info('<<<--------------------- Part Num [ %s ] ----------------------' % part_num)
                
            try:
                shutil.move(ongoing_path, pathjoin(SUCC_UNSTABLE_PART_NUM_FOLDER, basename(ongoing_path)))
                LOGGING.info('Prod store link file[%s] has been moved to SUCC folder!' % basename(ongoing_path))
            except Exception, e:
                LOGGING.error('Move file from [%s] to [%s] error: %s' % (ongoing_path, pathjoin(SUCC_UNSTABLE_PART_NUM_FOLDER, basename(ongoing_path)), traceback.format_exc()))
          
        except Exception, e:
            LOGGING.error('begin_read_prod_prices Error %s' % e)
        
        if not ComFun.is_day_night_time_switch(break_time_str):
            LOGGING.info('The time is close to the time node. break.')
            break
        
        ongoing_path = pickup_a_part_num()


if __name__ == "__main__":
    try:
        TIME_FLAG = False
        script_file_name = '.'.join(basename(__file__).split('.')[:-1])
        LOGGING = FileAndConsoleLogConfig(file_name = script_file_name, level = 'INFO')
        
        status, msg = ComFun.grant_script_running(script_file_name)
        if not status:
            LOGGING.error(msg + ', exit!')
            sys.exit()
        
        GOOGLE_BASE_LINK = 'https://www.google.com'
        READ_CONFIG = ParserConfigFile(r'./etc/price_metric_config.cfg')
        
        unstable_part_num_folder = pathjoin(READ_CONFIG.get_item_value('TXT_FOLDER', 'txt_base_path'), 
                                    READ_CONFIG.get_item_value('TXT_FOLDER', 'unstable_part_num_folder'))
        
        CUR_DATE = ComFun.getCurrentDate()
        NEW_UNSTABLE_PART_NUM_FOLDER     = pathjoin(unstable_part_num_folder, 'new')
        ONGOING_UNSTABLE_PART_NUM_FOLDER = pathjoin(unstable_part_num_folder, 'ongoing')
        SUCC_UNSTABLE_PART_NUM_FOLDER    = pathjoin(unstable_part_num_folder, 'succ', CUR_DATE)
        FAILED_UNSTABLE_PART_NUM_FOLDER  = pathjoin(unstable_part_num_folder, 'failed', CUR_DATE)
        
        if not exists(ONGOING_UNSTABLE_PART_NUM_FOLDER): os.makedirs(ONGOING_UNSTABLE_PART_NUM_FOLDER)
        if not exists(SUCC_UNSTABLE_PART_NUM_FOLDER):    os.makedirs(SUCC_UNSTABLE_PART_NUM_FOLDER)
        if not exists(FAILED_UNSTABLE_PART_NUM_FOLDER):  os.makedirs(FAILED_UNSTABLE_PART_NUM_FOLDER)
        
        try:
            DAY_TIME = READ_CONFIG.get_item_value('DEFAULT', 'day_time')
            NIGHT_TIME = READ_CONFIG.get_item_value('DEFAULT', 'night_time')
        except Exception, e:
            DAY_TIME = NIGHT_TIME = False
        
        
        if not DAY_TIME and not NIGHT_TIME:
            PN_UNSTABLE_EXPORT_XML_THREAD_COUNT = int(READ_CONFIG.get_item_value('DEFAULT', 'pn_unstable_export_xml_thread_count_day'))
        else:
            if ComFun.compareCurTimewithGivenTime(DAY_TIME) and not ComFun.compareCurTimewithGivenTime(NIGHT_TIME):
                PN_UNSTABLE_EXPORT_XML_THREAD_COUNT = int(READ_CONFIG.get_item_value('DEFAULT', 'pn_unstable_export_xml_thread_count_day'))
                TIME_FLAG = 'day_time'
            else:
                PN_UNSTABLE_EXPORT_XML_THREAD_COUNT = int(READ_CONFIG.get_item_value('DEFAULT', 'pn_unstable_export_xml_thread_count_night'))
                TIME_FLAG = 'night_time'
        
        UNSTABLE_PN_XML_BASE_PATH = pathjoin(READ_CONFIG.get_item_value('XML_FOLDER', 'unstable_pn_xml_base_path'), 'new')
        
        LOGGING.info('Script will be run with threading count[%s]' % str(PN_UNSTABLE_EXPORT_XML_THREAD_COUNT))
        
        threads = []
        for file_index in range(PN_UNSTABLE_EXPORT_XML_THREAD_COUNT):
            t = threading.Thread(target=begin_read_unstable_part_num)
            threads.append(t)
            t.start()
              
        for t in threads:
            t.join()
            
        if exists(script_file_name): ComFun.remove(script_file_name)
        LOGGING.info('DONE!.')
        
    except Exception, e:
        if LOGGING: LOGGING.error('Something wrong in the main: %s.' % traceback.format_exc())
        if exists(script_file_name):ComFun.remove(script_file_name)
    