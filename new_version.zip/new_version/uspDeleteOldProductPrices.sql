USE [PriceMetrics]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[uspDeleteOldProductPrices]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[uspDeleteOldProductPrices]
GO

USE [PriceMetrics]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ==================================================================
-- Author:		Jinyu Chen
-- Email:       jinyuc@fireracker.com
-- Create date: 03/21/2017 12:50:13
-- Description: Store Procedure will be triggered every day, 
-- and delete the product's price which old more than two months.
--
-- ==================================================================

CREATE PROCEDURE [dbo].[uspDeleteOldProductPrices]
	
AS
BEGIN
	SET NOCOUNT ON;

	DELETE FROM price_metrics where date <= DATEADD(MONTH, -2, GETDATE())

END